import withVideos from 'next-videos';

/** @type {import('next').NextConfig} */
const nextConfig = {
  // yahan aap additional configs daal sakte ho
};

export default withVideos(nextConfig);

