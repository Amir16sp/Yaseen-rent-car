"use client";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import FooterEnd from "../Footer/FooterEnd";
import Flowers from "../ShopNow/Flowers";
import Circle from "../slider/page"
import Benifit from "../age/benifit"
import bgImageDesktop from "../assets/images/aboutcar.jpg";
import bgImageMobile from "../assets/images/aboutcar.jpg";


// Animation config
const textAnimation = {
  initial: {
    opacity: 0,
    letterSpacing: "-0.5em",
    y: -100,
  },
  animate: {
    opacity: 1,
    letterSpacing: "0em",
    y: 0,
  },
  transition: {
    duration: 0.7,
    ease: [0.215, 0.61, 0.355, 1.0],
  },
};

const bookshopTitle = [
  { char: "A", color: "text-white-300" },
  { char: "b", color: "text-white-300" },
  { char: "o", color: "text-white-300" },
  { char: "u", color: "text-white-300" },
  { char: "t", color: "text-white-300" },
  

];

const Page = () => {
  const [shouldAnimate, setShouldAnimate] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShouldAnimate(true);
    }, 1300); // delay in ms before animation starts

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {/* Desktop Background */}
      <div
        className="hidden md:block h-[80vh] bg-cover bg-center relative"
        style={{ backgroundImage: `url(${bgImageDesktop.src})` }}
      >
        <div className="absolute bottom-0 text-[#ff3e00] flex items-center justify-center inset-0 ">
          <motion.h1
            className="text-7xl font-bold flex"
            initial="initial"
            animate={shouldAnimate ? "animate" : "initial"}
            variants={textAnimation}
            transition={textAnimation.transition}
          >
            {bookshopTitle.map((item, index) => (
              <span
                key={index}
                className={`${item.color} text-7xl`}
                style={{ WebkitTextStroke: "0.2px #FBDFB0" }}
              >
                {item.char}
              </span>
            ))}
          </motion.h1>
        </div>
      </div>

      {/* Mobile Background */}
      <div
        className="block md:hidden h-[50vh] bg-cover bg-center relative"
        style={{ backgroundImage: `url(${bgImageMobile.src})` }}
      >
        <div className="absolute inset-0 flex items-end justify-center p-4">
          <motion.h1
            className="text-3xl sm:text-4xl font-bold text-[#ff3e00] text-center"
            initial="initial"
            animate={shouldAnimate ? "animate" : "initial"}
            variants={textAnimation}
            transition={textAnimation.transition}
          >
            {bookshopTitle.map((item, index) => (
              <span
                key={index}
                className={`${item.color} text-4xl`}
                style={{ WebkitTextStroke: "0.2px #FBDFB0" }}
              >
                {item.char}
              </span>
            ))}
          </motion.h1>
        </div>
      </div>

     <Benifit/>
      <Flowers />
      <Circle />
      <FooterEnd />
    </>
  );
};

export default Page;
